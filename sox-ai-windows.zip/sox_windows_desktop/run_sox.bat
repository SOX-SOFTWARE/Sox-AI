@echo off
title SOX AI - Personal Assistant Launcher
echo ========================================================
echo               SOX AI Windows Desktop Edition
echo ========================================================
echo.

where python >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python 3.12+ from https://www.python.org/
    echo Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

if not exist ".venv" (
    echo [1/3] Creating Python Virtual Environment...
    python -m venv .venv
)

echo [2/3] Activating environment and checking dependencies...
call .venv\Scripts\activate.bat

echo [3/3] Installing/verifying requirements...
pip install -r requirements.txt --quiet

echo.
echo Starting SOX AI...
python sox_ai_app.py

pause
