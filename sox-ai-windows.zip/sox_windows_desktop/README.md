# SOX AI — Windows Desktop & Android Companion

SOX AI is a personal cinematic AI assistant designed for Windows PC and Android devices.

## Windows Desktop Setup (PySide6)

### 1. Requirements
- Python 3.12 or newer
- Windows 10 or 11
- Microphone & Audio output (for voice interaction)

### 2. Installation
```bash
cd sox_windows_desktop
python -m venv .venv
# On Windows PowerShell:
.venv\Scripts\Activate.ps1
# On CMD:
.venv\Scripts\activate.bat

pip install -r requirements.txt
```

### 3. Running SOX AI
```bash
python sox_ai_app.py
```

## Android Architecture Overview
- UI: Jetpack Compose with Material 3 Dark / Custom Theme
- Audio: Android `SpeechRecognizer` + `TextToSpeech`
- Automation: Android `Intent` system (`ACTION_VIEW`, `ACTION_DIAL`, `ACTION_WEB_SEARCH`) and SAF (Storage Access Framework)
- Local Cache: Room DB (SQLite) for memories, notes, and action audit logs
