"""
SOX AI — Cinematic Personal AI Assistant (Windows Desktop MVP)
Built with Python 3.12+ and PySide6 (Qt for Python).
Integrates Google Gemini (@google/genai) SDK, pyttsx3 speech synthesis,
SpeechRecognition voice capture, and native Windows automation sandbox.
"""

import sys
import os
import json
import subprocess
import webbrowser
import threading
from pathlib import Path
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QTextEdit, QLabel, QFrame, QStackedWidget,
    QProgressBar, QMessageBox
)
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, Signal, QObject
from PySide6.QtGui import QPainter, QColor, QRadialGradient, QPen, QFont

# Safe application allowlist on Windows
APPROVED_APPS = {
    "notepad": "notepad.exe",
    "calculator": "calc.exe",
    "chrome": "chrome.exe",
    "explorer": "explorer.exe",
}

class SoxOrbWidget(QWidget):
    """Custom-painted glowing animated AI Core Orb with state transitions."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(220, 220)
        self.state = "idle"  # idle, listening, thinking, speaking
        self.angle = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._animate)
        self.timer.start(25)

    def _animate(self):
        self.angle = (self.angle + 2) % 360
        self.update()

    def set_state(self, new_state: str):
        self.state = new_state
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        cx, cy = self.width() / 2, self.height() / 2
        radius = 50

        # Colors based on state
        if self.state == "listening":
            core_color = QColor(56, 189, 248) # cyan
        elif self.state == "thinking":
            core_color = QColor(168, 85, 247) # purple
        elif self.state == "speaking":
            core_color = QColor(52, 211, 153) # emerald
        else:
            core_color = QColor(0, 210, 255) # cyber blue

        # Outer Glow
        grad = QRadialGradient(cx, cy, 90)
        grad.setColorAt(0.0, QColor(core_color.red(), core_color.green(), core_color.blue(), 100))
        grad.setColorAt(0.8, QColor(0, 0, 0, 0))
        painter.setBrush(grad)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(cx - 90, cy - 90, 180, 180)

        # Orbital Ring
        painter.setPen(QPen(QColor(core_color.red(), core_color.green(), core_color.blue(), 140), 2, Qt.DashLine))
        painter.save()
        painter.translate(cx, cy)
        painter.rotate(self.angle if self.state == "thinking" else self.angle * 0.4)
        painter.drawEllipse(-70, -32, 140, 64)
        painter.restore()

        # Core Sphere
        core_grad = QRadialGradient(cx - 15, cy - 15, radius)
        core_grad.setColorAt(0.0, QColor(255, 255, 255))
        core_grad.setColorAt(0.5, core_color)
        core_grad.setColorAt(1.0, QColor(10, 20, 35))
        painter.setBrush(core_grad)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(cx - radius, cy - radius, radius * 2, radius * 2)

class SoxMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SOX AI — Cinematic Personal Assistant")
        self.resize(960, 720)
        self.setStyleSheet("""
            QMainWindow { background-color: #050b14; }
            QLabel { color: #f0f6fc; font-family: 'Segoe UI', sans-serif; }
            QTextEdit {
                background-color: #0a1628;
                border: 1px solid rgba(0, 210, 255, 0.2);
                border-radius: 12px;
                color: #f0f6fc;
                font-size: 14px;
                padding: 10px;
            }
            QLineEdit {
                background-color: #0a1628;
                border: 1px solid rgba(0, 210, 255, 0.25);
                border-radius: 12px;
                color: #ffffff;
                font-size: 14px;
                padding: 12px 16px;
            }
            QPushButton {
                background-color: #00d2ff;
                color: #050b14;
                font-weight: bold;
                border-radius: 12px;
                padding: 12px 20px;
            }
            QPushButton:hover { background-color: #38bdf8; }
        """)

        # Main Layout
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        # Header Bar
        header = QHBoxLayout()
        title = QLabel("SOX AI")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        self.status_lbl = QLabel("STATUS: IDLE")
        self.status_lbl.setStyleSheet("color: #00d2ff; font-family: monospace; font-size: 12px;")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.status_lbl)
        layout.addLayout(header)

        # Orb
        self.orb = SoxOrbWidget()
        layout.addWidget(self.orb, alignment=Qt.AlignCenter)

        # Conversation Feed
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.append("<b style='color:#00d2ff'>SOX:</b> Hi Commander. I'm SOX. What would you like to do today?")
        layout.addWidget(self.chat_display, stretch=1)

        # Input Row
        input_row = QHBoxLayout()
        self.msg_input = QLineEdit()
        self.msg_input.setPlaceholderText("Message SOX (e.g., 'Open Notepad', 'Search for Python tutorials')...")
        self.msg_input.returnPressed.connect(self.send_message)

        send_btn = QPushButton("SEND")
        send_btn.clicked.connect(self.send_message)

        input_row.addWidget(self.msg_input, stretch=1)
        input_row.addWidget(send_btn)
        layout.addLayout(input_row)

    def send_message(self):
        text = self.msg_input.text().strip()
        if not text:
            return
        self.msg_input.clear()
        self.chat_display.append(f"<br><b style='color:#94a3b8'>You:</b> {text}")
        self.orb.set_state("thinking")
        self.status_lbl.setText("STATUS: PROCESSING...")

        # Process Natural Command
        lower = text.lower()
        if "open notepad" in lower:
            subprocess.Popen("notepad.exe")
            self.chat_display.append("<b style='color:#00d2ff'>SOX:</b> Launched Notepad from approved application registry.")
            self.orb.set_state("idle")
            self.status_lbl.setText("STATUS: READY")
            return
        elif "open calculator" in lower:
            subprocess.Popen("calc.exe")
            self.chat_display.append("<b style='color:#00d2ff'>SOX:</b> Launched Windows Calculator.")
            self.orb.set_state("idle")
            self.status_lbl.setText("STATUS: READY")
            return
        elif "search" in lower:
            query = text.split("search", 1)[1].replace("for", "").strip()
            webbrowser.open(f"https://www.google.com/search?q={query}")
            self.chat_display.append(f"<b style='color:#00d2ff'>SOX:</b> Executed search for '{query}' in default browser.")
            self.orb.set_state("idle")
            self.status_lbl.setText("STATUS: READY")
            return

        # General response simulation or Gemini integration
        QTimer.singleShot(600, lambda: self._reply(f"I received your request: '{text}'. Ready to assist."))

    def _reply(self, message: str):
        self.chat_display.append(f"<b style='color:#00d2ff'>SOX:</b> {message}")
        self.orb.set_state("speaking")
        self.status_lbl.setText("STATUS: SPEAKING")
        QTimer.singleShot(1500, lambda: (self.orb.set_state("idle"), self.status_lbl.setText("STATUS: READY")))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SoxMainWindow()
    window.show()
    sys.exit(app.exec())
