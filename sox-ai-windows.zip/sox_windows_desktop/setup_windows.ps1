Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "             SOX AI Windows Desktop Setup              " -ForegroundColor White
Write-Host "========================================================" -ForegroundColor Cyan

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] Python is not installed. Please install Python 3.12+ from python.org" -ForegroundColor Red
    exit
}

if (-not (Test-Path ".venv")) {
    Write-Host "[1/2] Creating virtual environment..." -ForegroundColor Yellow
    python -m venv .venv
}

Write-Host "[2/2] Installing PySide6 and dependencies..." -ForegroundColor Yellow
& .venv\Scripts\pip install -r requirements.txt

Write-Host "Setup complete! Launching SOX AI..." -ForegroundColor Green
& .venv\Scripts\python sox_ai_app.py
